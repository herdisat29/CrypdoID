# CrypdoID — Strict Typing + Unit Testing Package

## File Structure

```
src/
  lib/
    audio.ts              ← window as any → WindowWithWebkit interface
  services/
    geminiService.ts      ← securityResult?: any → proper TokenSecurityResult type
    tokenSecurity.ts      ← tokenData: any → GoPlusTokenData + GeminiSimulatedData interfaces

tests/
  setup.ts                ← global mocks: localStorage, AudioContext, Firebase, wagmi
  unit/
    services/
      tokenSecurity.test.ts   ← 16 tests
    contexts/
      RewardContext.test.ts   ← 14 tests (verifyStreak, getTitleForLevel, getTitleColorClass)
    store/
      stores.test.ts          ← 16 tests (userStore + walletStore)
    lib/
      audio.test.ts           ← 8 tests

vitest.config.ts          ← vitest setup dengan jsdom + coverage
PACKAGE_ADDITIONS.json    ← deps + scripts yang perlu ditambah ke package.json
```

---

## Setup (3 langkah)

### 1. Install dependencies

```bash
npm install -D vitest @vitest/coverage-v8 @vitest/ui jsdom \
  @testing-library/react @testing-library/jest-dom @testing-library/user-event
```

### 2. Update package.json

Tambahkan ke `"scripts"`:
```json
"test": "vitest",
"test:run": "vitest run",
"test:coverage": "vitest run --coverage",
"test:ui": "vitest --ui"
```

### 3. Copy files ke project

```
vitest.config.ts          → root project
tests/                    → root project  
src/lib/audio.ts          → replace src/lib/audio.ts
src/services/geminiService.ts    → replace src/services/geminiService.ts
src/services/tokenSecurity.ts   → replace src/services/tokenSecurity.ts
```

---

## Jalankan tests

```bash
# Watch mode (development)
npm test

# Single run (CI)
npm run test:run

# With coverage report
npm run test:coverage

# Visual UI
npm run test:ui
```

---

## Typing fixes summary

| File | Before | After |
|---|---|---|
| `tokenSecurity.ts` | `let tokenData: any` | `GoPlusTokenData` interface |
| `tokenSecurity.ts` | `JSON.parse(text)` result untyped | `GeminiSimulatedData` interface |
| `geminiService.ts` | `securityResult?: any` | `securityResult?: TokenSecurityResult` |
| `audio.ts` | `(window as any).webkitAudioContext` | `WindowWithWebkit` interface |
| All files | `error as { message?: string }` | `error instanceof Error` pattern |

---

## Notes

- `tsconfig.json` lo sudah `"strict": true` — bagus, gak perlu diubah.
- Tests di-isolate dari Firebase/wagmi via global mocks di `tests/setup.ts`.
- Coverage target realistis untuk mulai: **70%** statements, naikin bertahap ke 85%+.
